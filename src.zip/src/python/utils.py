import json
import re


def fun(file):
    data = open(file, encoding="utf-8").readlines()
    backreference_and_subroutine_reference = 0
    backreference = 0
    subroutine_reference = 0
    for line in data:
        line = line[0:-1]
        if "embedded_code" in str(line) and "backreference "  in str(line):
            backreference_and_subroutine_reference += 1
        elif "backreference " in str(line):
            backreference += 1
        elif "subroutine_reference" in str(line):
            subroutine_reference += 1
    print("backreference_and_subroutine_reference:" + str(backreference_and_subroutine_reference))
    print("subroutine_reference:" + str(subroutine_reference))
    print("backreference:" + str(backreference))


fun("../../data/perl/result_perl.txt")
