/**
 * Copyright 2021 bejson.com
 */
package cn.ac.ios.Bean;

import java.util.List;

/**
 * Auto-generated: 2021-11-09 14:10:27
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class BaseDataBean {

    private String filename;
    private List<Regexps> regexps;

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilename() {
        return filename;
    }

    public void setRegexps(List<Regexps> regexps) {
        this.regexps = regexps;
    }

    public List<Regexps> getRegexps() {
        return regexps;
    }

}