/**
  * Copyright 2021 bejson.com 
  */
package cn.ac.ios.Bean;

/**
 * Auto-generated: 2021-11-09 14:10:27
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Regexps {

    private String pattern;
    private String flags;
    private String funcName;
    private int line;
    public void setPattern(String pattern) {
         this.pattern = pattern;
     }
     public String getPattern() {
         return pattern;
     }

    public void setFlags(String flags) {
         this.flags = flags;
     }
     public String getFlags() {
         return flags;
     }

    public void setFuncName(String funcName) {
         this.funcName = funcName;
     }
     public String getFuncName() {
         return funcName;
     }

    public void setLine(int line) {
         this.line = line;
     }
     public int getLine() {
         return line;
     }

}